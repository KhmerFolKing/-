const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

const players = {};
let gameState = 'waiting'; 
let countdownTimer = null;

const spawnPoints = [
    { x: 0, z: 22, rotationY: Math.PI }, 
    { x: 0, z: -22, rotationY: 0 }       
];
let spawnIndex = 0;

function resetRound() {
    gameState = 'waiting';
    let idx = 0;
    for (let id in players) {
        players[id].isReady = false;
        players[id].hp = 100;
        players[id].x = spawnPoints[idx % 2].x;
        players[id].y = 0.65;
        players[id].z = spawnPoints[idx % 2].z;
        players[id].rotationY = spawnPoints[idx % 2].rotationY;
        idx++;
    }
    io.emit('gameState', { state: 'waiting', players: players });
    io.emit('readyUpdate', players);
}

io.on('connection', (socket) => {
    console.log(`🟢 玩家加入: ${socket.id}`);

    players[socket.id] = {
        x: spawnPoints[spawnIndex % 2].x,
        y: 0.65,
        z: spawnPoints[spawnIndex % 2].z,
        rotationY: spawnPoints[spawnIndex % 2].rotationY,
        hp: 100,
        score: 0,
        isReady: false
    };
    spawnIndex++;

    socket.emit('currentPlayers', players);
    socket.broadcast.emit('newPlayer', { id: socket.id, playerInfo: players[socket.id] });
    io.emit('scoreUpdate', players);
    
    socket.emit('gameState', { state: gameState, players: players });
    socket.emit('readyUpdate', players);

    socket.on('toggleReady', () => {
        if (gameState !== 'waiting') return;
        players[socket.id].isReady = !players[socket.id].isReady;
        io.emit('readyUpdate', players);

        const pList = Object.values(players);
        if (pList.length === 2 && pList.every(p => p.isReady)) {
            gameState = 'countdown';
            io.emit('gameState', { state: 'countdown' });
            
            if (countdownTimer) clearInterval(countdownTimer);
            let count = 3;
            countdownTimer = setInterval(() => {
                io.emit('countdown', count);
                count--;
                if (count < 0) {
                    clearInterval(countdownTimer);
                    gameState = 'playing';
                    io.emit('gameState', { state: 'playing', players: players });
                }
            }, 1000);
        }
    });

    socket.on('playerMovement', (movementData) => {
        if (players[socket.id]) {
            players[socket.id].x = movementData.x;
            players[socket.id].y = movementData.y;
            players[socket.id].z = movementData.z;
            players[socket.id].rotationY = movementData.rotationY;
            socket.broadcast.emit('playerMoved', { id: socket.id, playerInfo: players[socket.id] });
        }
    });

    // 核心新增：通用声音广播系统 (起跳、开火、脚步)
    socket.on('playSound', (data) => {
        if (gameState === 'playing') {
            socket.broadcast.emit('enemySound', data);
        }
    });

    socket.on('hitPlayer', (data) => {
        if (gameState !== 'playing') return;

        const target = players[data.targetId];
        const attacker = players[socket.id];
        
        if (target && target.hp > 0 && attacker) {
            target.hp -= data.damage;
            
            if (target.hp <= 0) {
                target.hp = 0;
                attacker.score += 1; 
                gameState = 'roundEnd'; 
                io.emit('scoreUpdate', players);

                if (attacker.score >= 11) {
                    io.emit('gameOver', { winner: socket.id });
                    for (let id in players) {
                        players[id].score = 0;
                        players[id].hp = 100;
                        players[id].isReady = false;
                    }
                } else {
                    io.to(data.targetId).emit('youDied');
                    io.emit('playerDied', data.targetId);

                    setTimeout(() => {
                        resetRound();
                    }, 2000);
                }
            } else {
                io.emit('playerDamaged', { id: data.targetId, hp: target.hp });
            }
        }
    });

    socket.on('disconnect', () => {
        console.log(`🔴 玩家退出: ${socket.id}`);
        delete players[socket.id];
        io.emit('playerDisconnected', socket.id);
        io.emit('scoreUpdate', players); 

        if (Object.keys(players).length < 2 && gameState !== 'waiting') {
            if (countdownTimer) clearInterval(countdownTimer);
            resetRound();
        }
    });
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`🚀 战术声音系统已部署，服务器已启动！`);
});